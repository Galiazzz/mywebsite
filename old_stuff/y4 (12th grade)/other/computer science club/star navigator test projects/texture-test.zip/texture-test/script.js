var vertexShader = `#version 300 es
		layout(std140) uniform Uniforms{
				mat4 transform;
    };

	  layout(location = 0) in vec2 position;

	 	out float zPos;
		void main(){
			vec4 transformed = vec4(position, 0.0, 1.0) * transform;
	 		zPos =  3.0 - position.y;
			gl_Position = vec4(transformed.xy, transformed.z * transformed.z * 0.001, 1.0);
		}
`
var fragmentShader = `#version 300 es
		precision highp float;

 		out vec4 pixel_color;
	 	in float zPos;
		void main(){
			pixel_color = vec4(0, 1.0 / (zPos), .2, 1);
		}
`


var canvas = document.getElementById("canvas");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
var gl = canvas.getContext("webgl2");

var positions = [1, 1, -1, -1, 1, -1];
var positionBuffer;

var VAO;

var program;

var UBO;
var UBOIndex;
const UBOVariableNames = ["transform"];
var UBOVariableIndicies;
var UBOVariableOffsets;

var camX = 0;
var camY = 0;
var camZ = 0;

var yAngle = 0, xAngle = 0;

var zoom = 1;

var points = [];
var gridX = 100, gridZ = 100;


function loadStuff() {
	program = CreateProgram(vertexShader, fragmentShader);

	//Uniform Buffer setup
	UBOIndex = gl.getUniformBlockIndex(program, "Uniforms");
	var blockSize = gl.getActiveUniformBlockParameter(program, UBOIndex, gl.UNIFORM_BLOCK_DATA_SIZE);
	UBO = gl.createBuffer();
	gl.bindBuffer(gl.UNIFORM_BUFFER, UBO);
	gl.bufferData(gl.UNIFORM_BUFFER, blockSize, gl.DYNAMIC_DRAW);
	gl.bindBuffer(gl.UNIFORM_BUFFER, null);

	//the 0 is the index of the uniform block
	gl.bindBufferBase(gl.UNIFORM_BUFFER, 0, UBO);

	//for both the indicies and offsets, index 0 is screenSize, index 1 is cameraPos, index 2 is transform mat
	UBOVariableIndicies = gl.getUniformIndices(program, UBOVariableNames);
	UBOVariableOffsets = gl.getActiveUniforms(program, UBOVariableIndicies, gl.UNIFORM_OFFSET);
	//create VAO
	VAO = gl.createVertexArray();
	gl.bindVertexArray(VAO);

	positionBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positions), gl.STATIC_DRAW);
	gl.enableVertexAttribArray(0);
	gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);

	requestAnimationFrame(draw);
}


function draw(){
	canvas.height = window.innerHeight;
	canvas.width = window.innerWidth;

	gl.clearColor(0.25, 0, 0.25, 1);
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	var index = gl.getUniformBlockIndex(program, "Uniforms");
	gl.uniformBlockBinding(program, index, 0); // the 0 is the index of the uniform block

	gl.bindBuffer(gl.UNIFORM_BUFFER, UBO);
	var translate = [
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	];

	var combined = translate

	gl.bufferSubData(gl.UNIFORM_BUFFER, UBOVariableOffsets[0], new Float32Array(combined));
	gl.bindBuffer(gl.UNIFORM_BUFFER, null);

	gl.viewport(0, 0, canvas.width, canvas.height);
	gl.useProgram(program);
	gl.bindVertexArray(VAO);
	gl.drawArrays(gl.TRIANGLES, 0, 3);

	requestAnimationFrame(draw);
}

function MulMatrix4x4(leftMat, rightMat) {
	return [
		rightMat[0] * leftMat[0] + rightMat[4] * leftMat[1] + rightMat[8] * leftMat[2] + rightMat[12] * leftMat[3], rightMat[1] * leftMat[0] + rightMat[5] * leftMat[1] + rightMat[9] * leftMat[2] + rightMat[13] * leftMat[3], rightMat[2] * leftMat[0] + rightMat[6] * leftMat[1] + rightMat[10] * leftMat[2] + rightMat[14] * leftMat[3], rightMat[3] * leftMat[0] + rightMat[7] * leftMat[1] + rightMat[11] * leftMat[2] + rightMat[15] * leftMat[3],
		rightMat[0] * leftMat[4] + rightMat[4] * leftMat[5] + rightMat[8] * leftMat[6] + rightMat[12] * leftMat[7], rightMat[1] * leftMat[4] + rightMat[5] * leftMat[5] + rightMat[9] * leftMat[6] + rightMat[13] * leftMat[7], rightMat[2] * leftMat[4] + rightMat[6] * leftMat[5] + rightMat[10] * leftMat[6] + rightMat[14] * leftMat[7], rightMat[3] * leftMat[4] + rightMat[7] * leftMat[5] + rightMat[11] * leftMat[6] + rightMat[15] * leftMat[7],
		rightMat[0] * leftMat[8] + rightMat[4] * leftMat[9] + rightMat[8] * leftMat[10] + rightMat[12] * leftMat[11], rightMat[1] * leftMat[8] + rightMat[5] * leftMat[9] + rightMat[9] * leftMat[10] + rightMat[13] * leftMat[11], rightMat[2] * leftMat[8] + rightMat[6] * leftMat[9] + rightMat[10] * leftMat[10] + rightMat[14] * leftMat[11], rightMat[3] * leftMat[8] + rightMat[7] * leftMat[9] + rightMat[11] * leftMat[10] + rightMat[15] * leftMat[11],
		rightMat[0] * leftMat[12] + rightMat[4] * leftMat[13] + rightMat[8] * leftMat[14] + rightMat[12] * leftMat[15], rightMat[1] * leftMat[12] + rightMat[5] * leftMat[13] + rightMat[9] * leftMat[14] + rightMat[13] * leftMat[15], rightMat[2] * leftMat[12] + rightMat[6] * leftMat[13] + rightMat[10] * leftMat[14] + rightMat[14] * leftMat[15], rightMat[3] * leftMat[12] + rightMat[7] * leftMat[13] + rightMat[11] * leftMat[14] + rightMat[15] * leftMat[15]
	];
}

function CreateShader(source, type) {
	var shader = gl.createShader(type);
	gl.shaderSource(shader, source);
	gl.compileShader(shader);
	var success = gl.getShaderParameter(shader, gl.COMPILE_STATUS);
	if (success) {
		return shader;
	}
	console.error(gl.getShaderInfoLog(shader));
	alert(gl.getShaderInfoLog(shader))
	gl.deleteShader(shader);
}

function CreateProgram(vertexSource, fragmentSource) {
	var vertexShader = CreateShader(vertexSource, gl.VERTEX_SHADER);
	var fragmentShader = CreateShader(fragmentSource, gl.FRAGMENT_SHADER);

	var ShaderProgram = gl.createProgram();
	gl.attachShader(ShaderProgram, vertexShader);
	gl.attachShader(ShaderProgram, fragmentShader);

	gl.linkProgram(ShaderProgram);
	var success = gl.getProgramParameter(ShaderProgram, gl.LINK_STATUS);
	if (success) {
		return ShaderProgram;
	}
	console.error(gl.getProgramInfoLog(ShaderProgram));
	gl.deleteProgram(ShaderProgram);
}