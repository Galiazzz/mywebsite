var homeVertex = `#version 300 es
		layout(std140) uniform Uniforms{
				mat4 transform;
    };

	  layout(location = 0) in vec3 position;

	 	out float zPos;
		void main(){
			vec4 transformed = vec4(position, 1.0);// * transform;
	 		zPos =  3.0 - position.y;
			gl_Position = vec4(transformed.xy, transformed.z * transformed.z * 0.001, transformed.z);
		}
`
var homeFragment = `#version 300 es
		precision highp float;

 		out vec4 pixel_color;
	 	in float zPos;
		void main(){
			pixel_color = vec4(0, 1.0, .2, 1);
		}
`

var homePositions = [0, 1, 0,  -1, -1, 0,  1, -1, 0];
var homePositionBuffer;

var homeVAO = gl.createVertexArray();
	gl.bindVertexArray(homeVAO);

	positionBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, homePositionBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(homePositions), gl.STATIC_DRAW);
	gl.enableVertexAttribArray(0);
	gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);

var homeProgram = CreateProgram(homeVertex, homeFragment);

