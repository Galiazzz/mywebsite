var vCanvas = document.getElementById("dataVis");
var vCtx = vCanvas.getContext("2d");
vCanvas.width = window.innerWidth;
vCanvas.height = window.innerHeight * 0.45;

var dCanvas = document.getElementById("density");
var dCtx = dCanvas.getContext("2d");
dCanvas.width = window.innerWidth;
dCanvas.height = window.innerHeight * 0.45;

var data = []

function loadStuff(){
	for(var i = 0; i < 100; i++){
		data.push(Math.random());
	}
	for(var i = 0; i < 100; i++){
		data.push(0.5 + (Math.random() - 0.5) * 0.2);
	}

	for(var i of data){
		vCtx.fillRect(vCanvas.width * i, vCanvas.height / 2, 1, 1);
	}

	calculateDensityNaive();
}

function calculateDensityNaive(){
	//var temp = data.sort();
	var points = [];
	var blockSize = 0.05;
	var resolution = 1000;
	for(var i = 0; i < resolution; i++){
		var numPoints = 0;
		for(var v of data){
			if(Math.abs(v - i / resolution) < blockSize / 2){
				numPoints++;
			}
		}
		points.push(numPoints / (Math.min(1, i/resolution + blockSize / 2) - Math.max(0, i/resolution - blockSize / 2)));
	}
	dCtx.moveTo(0, dCanvas.height - points[0] * 0.25);
	console.log(points[0]);
	for(var i = 1; i < points.length; i++){
		dCtx.lineTo(i/resolution * dCanvas.width, dCanvas.height -points[i] * 0.25);
	}
	dCtx.stroke();
}