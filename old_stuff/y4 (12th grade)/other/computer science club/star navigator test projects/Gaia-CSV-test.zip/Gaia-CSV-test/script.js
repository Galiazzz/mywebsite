var data;

var dataRequest = new XMLHttpRequest();
dataRequest.onload = function(){
	data = this.responseText;
	formatData();
}
dataRequest.open("GET", "1674667919201O-result.csv");
dataRequest.send();

function formatData(){
	data = data.split("\n");
	for(var i = 0; i < data.length; i++){
		data[i] = data[i].split(",");
	}
	var maxLength = 0;
	for(var a of data){
		for(var s of a){
			maxLength = Math.max(maxLength, s.length);
		}
	}
	var box = document.getElementById("display");
	console.log(box)
	for(var a of data){
		for(var s of a){
			while(s.length < maxLength){
				s = s + " ";
			}
			box.innerHTML += s + ", ";
		}
		box.innerHTML += "<br>";
	}
}