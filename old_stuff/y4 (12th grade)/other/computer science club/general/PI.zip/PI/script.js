var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
canvas.height = window.innerHeight;
canvas.width = window.innerWidth;

function loadStuff(){
  ctx.strokeStyle = "green";
  ctx.beginPath();
	ctx.arc(canvas.width / 2, canvas.height / 2, 50, 0, 2 * Math.PI);
	ctx.stroke();
  ctx.beginPath();
  ctx.strokeStyle = "red";
  ctx.rect(canvas.width/2 - 50, canvas.height/2 - 50, 100,100);
  ctx.stroke();

	var numPoints = 1000;

	var pointsInCircle = 0;
	for(var i = 0; i < numPoints; i++){
		console.log(i)
		var pointX = Math.random() * 100 - 50;
		var pointY = Math.random() * 100 - 50;
    ctx.fillStyle = "blue";
		ctx.beginPath();
		ctx.arc(canvas.width / 2 + pointX, canvas.height / 2 + pointY, 2, 0, 2 * Math.PI);
		ctx.fill();

		var distSquared = pointX * pointX + pointY * pointY;
		if(distSquared < 50 * 50){
			pointsInCircle++;
		}
	}
	var estPi = 4 * pointsInCircle / numPoints;
	document.getElementById("display").innerText = estPi;
} 

function distance(x1, y1, x2, y2) {
  return Math.sqrtx()
}