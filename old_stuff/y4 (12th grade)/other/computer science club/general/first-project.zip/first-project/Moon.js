class Moon {
  constructor(radius, color, orbitRadius){
    this.radius = 30;
    this.color = color;
    this.mass = 500 * this.radius;
    this.orbitRadius = orbitRadius;
    this.angularVelocity = Math.sqrt(0.0025 * this.mass / (this.orbitRadius * this.orbitRadius));
    this.angularPosition = this.angularVelocity * time;
  }

  

  Draw(planetX, planetY) {
		ctx.fillStyle = this.color;
		ctx.beginPath();
    var scrCoord = worldToScreenCoordinate(planetX + Math.cos(this.angularPosition) * this.orbitRadius, planetY + Math.sin(this.angularPosition) * this.orbitRadius);
		ctx.arc(scrCoord.x, scrCoord.y, this.radius * zoom, 0, 2*Math.PI);
    ctx.fill();
    this.angularPosition += this.angularVelocity;
	}
}
