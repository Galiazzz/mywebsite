

var keysDown = [];

const Keys = {
	up: 0,
  left: 1,
  down: 2,
  right: 3,
  rotLeft: 4,
  rotRight: 5,
  pause: 6,
	brake: 7,
  zoomOut: 8,
  zoomIn: 9,
  camReset: 10,
  camUp: 11,
  camLeft: 12,
  camDown: 13,
  camRight: 14
};

for(var i = 0; i < 15; i++){
	keysDown[i] = false;
}


document.addEventListener('keydown', (event) => {
	if (event.key == "w") {
    keysDown[Keys.up] = true;
  }
  if ((event.key == "a")) {
    keysDown[Keys.left] = true;
  }
  if ((event.key == "s")) {
    keysDown[Keys.down] = true;
	}
  if ((event.key == "d")) {
    keysDown[Keys.right] = true;
  }
	if (event.key == "q") {
    keysDown[Keys.rotLeft] = true;
	}
  if (event.key == "e") {
    keysDown[Keys.rotRight] = true;
  }
  if (event.key == "p") {
    isPaused = !isPaused;
  }
	if (event.key == "b") {
		keysDown[Keys.brake] = true;
	}
  if (event.key == "-") {
    zoom *= 0.5;
    xOff *= 0.5;
		yOff *= 0.5;
  }
  if (event.key == "=") {
    zoom *= 2;
		xOff *= 2;
		yOff *= 2;
  }
  if (event.key == "0") {
    zoom = 1;
		xOff = 0;
		yOff = 0;
  }
	if(event.key == "ArrowUp"){
		keysDown[Keys.camUp] = true;
	}
	if(event.key == "ArrowLeft"){
		keysDown[Keys.camLeft] = true;
	}
	if(event.key == "ArrowDown"){
		keysDown[Keys.camDown] = true;
	}
	if(event.key == "ArrowRight"){
		keysDown[Keys.camRight] = true;
	}
});

document.addEventListener('keyup', (event) => {
	if ((event.key == "w")) {
    keysDown[Keys.up] = false;
  }
  if ((event.key == "a")) {
    keysDown[Keys.left] = false;
  }
  if ((event.key == "s")) {
    keysDown[Keys.down] = false;
	}
  if ((event.key == "d")) {
    keysDown[Keys.right] = false;
  }
	if (event.key == "q") {
    keysDown[Keys.rotLeft] = false;
	}
  if (event.key == "e") {
    keysDown[Keys.rotRight] = false;
  }
	if (event.key == "b") {
		keysDown[Keys.brake] = false;
	}
  if(event.key == "ArrowUp"){
		keysDown[Keys.camUp] = false;
	}
	if(event.key == "ArrowLeft"){
		keysDown[Keys.camLeft] = false;
	}
	if(event.key == "ArrowDown"){
		keysDown[Keys.camDown] = false;
	}
	if(event.key == "ArrowRight"){
		keysDown[Keys.camRight] = false;
	}
});