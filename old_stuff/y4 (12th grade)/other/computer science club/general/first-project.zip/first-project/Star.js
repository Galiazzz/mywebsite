class Star{
  constructor(x, y, color, radius){
    this.x = x;
    this.y = y;
    this.color = color;
    this.radius = radius;
    this.mass = 500 * this.radius;
    
    this.planets = [];

    for (var i = 0; i < gen.numPlanets(this.x, this.y); i++) {
      this.planets.push(new Planet(gen.size(this.x + this.radius * (i + 2), this.y, this.radius * 0.6), gen.color(this.x + this.radius * (i + 2), this.y), this.radius * (i + 2), this.x, this.y, i));
    }
		
  }
  // use this class for collision detection, then loop through planets/moons in system
  // this approach could be used for gravity?

  Draw(){
    ctx.fillStyle = this.color;
		ctx.beginPath();
    var scrCoord = worldToScreenCoordinate(this.x, this.y);
		ctx.arc(scrCoord.x, scrCoord.y, this.radius * zoom, 0, 2*Math.PI);
    ctx.fill();
    
    for (var i = 0; i < this.planets.length; i++) {
      this.planets[i].Draw();
    }
    
  }
}