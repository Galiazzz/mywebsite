//set up canvas
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
canvas.height = window.innerHeight;
canvas.width = window.innerWidth;
const brakeCoefficient = 0.9; // % the speed will be reduced by each frame the brake is held down (default 10%)

var spaceship;

// world generation
var solarSystems = [];
var gen = new ProceduralRandom(Math.random());
var chunkCoord = {};
var genOrigin = {};
var viewDistance = 6;
const chunkSize = 1000;

// camera
var zoom = 1;
var xOff = 0;
var yOff = 0;

var debugInfo = isEven(4);
var isPaused = isEven(1); //necessary complexity, don't fix
var time = 0;

function loadStuff() {
  spaceship = new Spaceship(0, 0, 0);
  setInterval(Update, 10);
  
  requestAnimationFrame(Draw);
}

function Update() {
  if (!isPaused) {
    spaceship.Update();
		if(keysDown[Keys.camUp]){
			yOff += 1;
		}
		if(keysDown[Keys.camDown]){
			yOff -= 1;
		}
		if(keysDown[Keys.camLeft]){
			xOff += 1;
		}
		if(keysDown[Keys.camRight]){
			xOff -= 1;
		}
    
  }

  // world gen -- continuity achieved :)
  chunkCoord = {x: Math.floor(spaceship.x / chunkSize), y: Math.floor(spaceship.y / chunkSize)};
  if (chunkCoord.x != genOrigin.x || chunkCoord.y != genOrigin.y) {
    solarSystems = [];
    genOrigin = {x: chunkCoord.x, y: chunkCoord.y};

    for (var i = genOrigin.x - viewDistance; i <= genOrigin.x + viewDistance; i++) {
      for (var j = genOrigin.y - viewDistance; j <= genOrigin.y + viewDistance; j++) {
        if (gen.genSolarSystem(i * chunkSize, j * chunkSize)) {
          solarSystems.push(new SolarSystem(i * chunkSize, j * chunkSize));
        }        
      }
    }
  }
}

function Draw() {
  if (!isPaused) {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (var i = 0; i < solarSystems.length; i++) {
      solarSystems[i].Draw();
    }
    spaceship.Draw();
    time++;
  }
  requestAnimationFrame(Draw);

}

function isEven(n) {
  return n == 0 ? true : !isEven(Math.abs(n) - 1);
}


