function rightflame(){
  ctx.beginPath();
  ctx.fillStyle = "yellow";
	var point1 = spaceshipToScreenCoordinate(15, -30);
	var point2 = spaceshipToScreenCoordinate(15, -24);
	var point3 = spaceshipToScreenCoordinate(25, -27);
	ctx.moveTo(point1.x, point1.y);
	ctx.lineTo(point2.x, point2.y);
	ctx.lineTo(point3.x, point3.y);
  ctx.fill();
}
function leftflame(){
  ctx.beginPath();
  ctx.fillStyle = "yellow";
	var point1 = spaceshipToScreenCoordinate(-15, -30);
	var point2 = spaceshipToScreenCoordinate(-15, -24);
	var point3 = spaceshipToScreenCoordinate(-25, -27);
	ctx.moveTo(point1.x, point1.y);
	ctx.lineTo(point2.x, point2.y);
	ctx.lineTo(point3.x, point3.y);
  ctx.fill();
}

function mainflame() {
  ctx.beginPath();
	var gradientCenter = spaceshipToScreenCoordinate(0, 30);
  const gradient = ctx.createRadialGradient(gradientCenter.x, gradientCenter.y, 5 * zoom, gradientCenter.x, gradientCenter.y, 40 * zoom);
  gradient.addColorStop(0, "teal");
  gradient.addColorStop(0.3, "firebrick");
  gradient.addColorStop(0.75, "darkorange");
  gradient.addColorStop(1, "gold");
  
  ctx.fillStyle = gradient;
	var point1 = spaceshipToScreenCoordinate(-12, 35);
	var point2 = spaceshipToScreenCoordinate(-25, 60);
	var point3 = spaceshipToScreenCoordinate(-12, 50);
	var point4 = spaceshipToScreenCoordinate(-16, 90);
	var point5 = spaceshipToScreenCoordinate(0, 75);
	var point6 = spaceshipToScreenCoordinate(16, 90);
	var point7 = spaceshipToScreenCoordinate(12, 50);
	var point8 = spaceshipToScreenCoordinate(25, 60);
	var point9 = spaceshipToScreenCoordinate(12, 35);
  ctx.moveTo(point1.x, point1.y);
  ctx.lineTo(point2.x, point2.y);
  ctx.lineTo(point3.x, point3.y);
  ctx.lineTo(point4.x, point4.y);
  ctx.lineTo(point5.x, point5.y);
  ctx.lineTo(point6.x, point6.y);
  ctx.lineTo(point7.x, point7.y);
  ctx.lineTo(point8.x, point8.y);
  ctx.lineTo(point9.x, point9.y);
  ctx.fill();
}