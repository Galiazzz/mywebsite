
function worldToScreenCoordinate(x, y) {
  var shipPos = worldToSpaceshipCoordinate(x, y);
  return spaceshipToScreenCoordinate(shipPos.x, shipPos.y);
}

function worldToSpaceshipCoordinate(x, y){
	var xs = x - spaceship.x;
  var ys = y - spaceship.y;

  var temp = rotatePoint(xs, ys, spaceship.rotation);

  return temp;
}

function spaceshipToScreenCoordinate(x, y) {
	var xs = x * zoom + canvas.width / 2 + xOff;
	var ys = y * zoom + canvas.height / 2 + yOff;

	return {x: xs, y: ys};
}

function rotatePoint(x, y, theta){
  return {x: (x * Math.cos(theta) - y * Math.sin(theta)), y: (x * Math.sin(theta) + y * Math.cos(theta))}
}