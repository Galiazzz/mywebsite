class ProceduralRandom {
  constructor(seed) {
    this.seed = seed;
  }
  // helper function, returns distance from origin
  distance(x, y) {
    return Math.sqrt(x * x + y * y);
  }

  genSolarSystem(x, y) {
    // 25% chance of generation
    return (this.seed * this.distance(x, y)) % 100 >= 75;
  }
  
  color(x, y) {
    var num = this.seed * this.distance(x, y);
    var r = num % 256;
    var g = num * 2 % 256;
    var b = num * 3 % 256;
    return `rgb(${r}, ${g}, ${b})`;
  }
  
  size(x, y, limit) {
    return this.seed * this.distance(x, y) % limit;
  }

  numPlanets(x, y) {
    return this.seed * this.distance(x, y) % 7 + 1;
  }

  numMoons(starX, starY, planetNum) {
    return this.seed * this.distance(starX, starY) * planetNum % 2;
  }

}