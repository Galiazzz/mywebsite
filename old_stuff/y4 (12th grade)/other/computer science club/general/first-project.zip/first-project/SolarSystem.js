class SolarSystem{
  constructor(x, y){
    this.x = x;
    this.y = y;
    this.star = new Star(this.x, this.y, gen.color(this.x, this.y), gen.size(this.x, this.y, 200));
  }
  Draw() {
    this.star.Draw();
  }
}