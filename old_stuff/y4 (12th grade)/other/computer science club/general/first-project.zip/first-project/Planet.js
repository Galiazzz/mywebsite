class Planet {
  constructor(radius, color, orbitRadius, starX, starY, planetIndex) {
    this.radius = radius;
    this.color = color;
    this.mass = 500 * this.radius;
    this.orbitRadius = orbitRadius;
    this.angularVelocity = Math.sqrt(0.0025 * this.mass / (this.orbitRadius * this.orbitRadius));
    this.angularPosition = this.angularVelocity * time;
    this.moons = [];
    this.starX = starX;
    this.starY = starY;
    this.planetIndex = planetIndex;

    
    for (var i = 0; i < gen.numMoons(this.starX, this.starY, this.planetIndex); i++) {
      var pos = {x: this.starX + this.orbitRadius, y: this.starY + this.radius * (i + 2)};
      this.moons.push(new Moon(gen.size(pos.x, pos.y, this.size), gen.color(pos.x, pos.y), this.radius * (i + 2)));
    }

  }

  Draw() {
    ctx.fillStyle = this.color;
    ctx.beginPath();
    var scrCoord = worldToScreenCoordinate(this.starX + Math.cos(this.angularPosition) * this.orbitRadius, this.starY + Math.sin(this.angularPosition) * this.orbitRadius);
    ctx.arc(scrCoord.x, scrCoord.y, this.radius * zoom, 0, 2 * Math.PI);
    ctx.fill();
    this.angularPosition += this.angularVelocity;
    
    for (var i = 0; i < this.moons.length; i++) {
      this.moons[i].Draw(this.starX + Math.cos(this.angularPosition) * this.orbitRadius, this.starY + Math.sin(this.angularPosition) * this.orbitRadius);
    }
    
  }

}