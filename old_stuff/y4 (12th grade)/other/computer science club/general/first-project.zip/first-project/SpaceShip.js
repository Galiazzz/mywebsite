class Spaceship {
  constructor(x, y, rotation) {
    this.x = x;
    this.y = y;
    this.velocityX = 0;
    this.velocityY = 0;
    this.rotation = rotation;
    this.angularVelocity = 0;

    this.linearAcceleration = 0.1;
    this.angularAcceleration = 0.00025;
  }

  Draw() {
    // body
    ctx.beginPath();
    ctx.fillStyle = "white";
		var bodyOrigin = spaceshipToScreenCoordinate(-15, -35);
		var bodyRightCorner = spaceshipToScreenCoordinate(15, 35);
    ctx.fillRect(bodyOrigin.x, bodyOrigin.y, bodyRightCorner.x - bodyOrigin.x, bodyRightCorner.y - bodyOrigin.y);
    // nose cone
    ctx.fillStyle = "red";
		var tringleTop = spaceshipToScreenCoordinate(0, -70);
    ctx.moveTo(tringleTop.x, tringleTop.y);
		var tringleLeft = spaceshipToScreenCoordinate(-20, -34);
    ctx.lineTo(tringleLeft.x, tringleLeft.y);
		var tringleRight = spaceshipToScreenCoordinate(20, -34);
    ctx.lineTo(tringleRight.x, tringleRight.y);
    ctx.fill();
    // left fin
    ctx.beginPath();
		var point1 = spaceshipToScreenCoordinate(-10, 5);
		var point2 = spaceshipToScreenCoordinate(-13, 4);
		var point3 = spaceshipToScreenCoordinate(-20, 15);
		var point4 = spaceshipToScreenCoordinate(-30, 38);
		var point5 = spaceshipToScreenCoordinate(-10, 38);
		var point6 = spaceshipToScreenCoordinate(-12, 24);
    ctx.moveTo(point1.x, point1.y);
    ctx.lineTo(point2.x, point2.y);
    ctx.lineTo(point3.x, point3.y);
    ctx.lineTo(point4.x, point4.y);
    ctx.lineTo(point5.x, point5.y);
    ctx.lineTo(point6.x, point6.y);
    ctx.fill();
    // right fin
    ctx.beginPath();
		point1 = spaceshipToScreenCoordinate(10, 5);
		point2 = spaceshipToScreenCoordinate(13, 4);
		point3 = spaceshipToScreenCoordinate(20, 15);
		point4 = spaceshipToScreenCoordinate(30, 38);
		point5 = spaceshipToScreenCoordinate(10, 38);
		point6 = spaceshipToScreenCoordinate(12, 24);
    ctx.moveTo(point1.x, point1.y);
    ctx.lineTo(point2.x, point2.y);
    ctx.lineTo(point3.x, point3.y);
    ctx.lineTo(point4.x, point4.y);
    ctx.lineTo(point5.x, point5.y);
    ctx.lineTo(point6.x, point6.y);
    ctx.fill();
    // details
    ctx.fillStyle = "black";
		var topLeft = spaceshipToScreenCoordinate(-6, 0); 
    var bottomRight = spaceshipToScreenCoordinate(6, 2);
    ctx.fillRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y)
		topLeft = spaceshipToScreenCoordinate(-6, 9); bottomRight = spaceshipToScreenCoordinate(6, 11);
    ctx.fillRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y)
		topLeft = spaceshipToScreenCoordinate(-6, 18); bottomRight = spaceshipToScreenCoordinate(6, 20);
    ctx.fillRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y)
		topLeft = spaceshipToScreenCoordinate(-6, 27); bottomRight = spaceshipToScreenCoordinate(6, 29);
    ctx.fillRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y)
		topLeft = spaceshipToScreenCoordinate(-1.5, -50); bottomRight = spaceshipToScreenCoordinate(1.5, -40);
    ctx.fillRect(topLeft.x, topLeft.y, bottomRight.x - topLeft.x, bottomRight.y - topLeft.y)

    // window
    ctx.beginPath();
    ctx.fillStyle = "lightskyblue";
		var windowCenter = spaceshipToScreenCoordinate(0, -16);
    ctx.arc(windowCenter.x, windowCenter.y, 10 * zoom, 0, 2 * Math.PI);
    ctx.fill();

    if (keysDown[Keys.rotLeft]) {
      rightflame();
    }
    if (keysDown[Keys.rotRight]) {
      leftflame();
    }
    if (keysDown[Keys.up]) {
      mainflame();
    }

    if (debugInfo) {
      ctx.fillStyle = "white";
      ctx.font = "14px sans-serif"
      // position info
      ctx.fillText("x: " + spaceship.x.toFixed(2) + " y: " + spaceship.y.toFixed(2) + " r: " + (spaceship.rotation % (2 * Math.PI) / Math.PI).toFixed(2) + "PI rdeg: " + ((spaceship.rotation / Math.PI * 180) % 360).toFixed(1), 10, 20);
      // velocity info
      ctx.fillText("vx: " + spaceship.velocityX.toFixed(2) + " vy: " + spaceship.velocityY.toFixed(2) + " vr: " + (spaceship.angularVelocity % (2 * Math.PI)).toFixed(5) + " vrdeg: " + ((spaceship.angularVelocity / Math.PI * 180) % 360).toFixed(2), 10, 40);
      // misc info
      ctx.fillText("zoom: " + zoom + " time: " + time, 10, 60);
      // generation info
      ctx.fillText(`cx: ${chunkCoord.x}, cy: ${chunkCoord.y}, seed: ${gen.seed}`, 10, 80);
      
    }
  }

  Update() {
    if (keysDown[Keys.up]) {
      spaceship.velocityX -= this.linearAcceleration * Math.sin(spaceship.rotation);
      spaceship.velocityY -= this.linearAcceleration * Math.cos(spaceship.rotation);
    }
    if (keysDown[Keys.left]) {
      spaceship.velocityX -= this.linearAcceleration * Math.cos(spaceship.rotation);
      spaceship.velocityY += this.linearAcceleration * Math.sin(spaceship.rotation);
    }
    if (keysDown[Keys.down]) {
      spaceship.velocityX += this.linearAcceleration * Math.sin(spaceship.rotation);
      spaceship.velocityY += this.linearAcceleration * Math.cos(spaceship.rotation);
    }
    if (keysDown[Keys.right]) {
      spaceship.velocityX += this.linearAcceleration * Math.cos(spaceship.rotation);
      spaceship.velocityY -= this.linearAcceleration * Math.sin(spaceship.rotation);
    }
    if (keysDown[Keys.rotLeft]) {
      spaceship.angularVelocity += this.angularAcceleration;
    }
    if (keysDown[Keys.rotRight]) {
      spaceship.angularVelocity -= this.angularAcceleration;
    }

    this.x += this.velocityX;
    this.y += this.velocityY;
    this.rotation += this.angularVelocity;

		spaceship.angularVelocity *= Math.pow(brakeCoefficient, 0.1);

		if(Math.abs(this.angularVelocity) > 0.001){
			xOff = 0;
			yOff = 0;
		}
		
    if (keysDown[Keys.brake]) {
      spaceship.velocityX *= brakeCoefficient
      spaceship.velocityY *= brakeCoefficient
      spaceship.angularVelocity *= brakeCoefficient
    }
  }

}
