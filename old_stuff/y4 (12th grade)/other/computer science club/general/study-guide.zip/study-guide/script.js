class Question{
	constructor(displayQ, answers, correctA){
		this.displayQ = displayQ;
		this.answers = answers;
		this.correct = correctA;
	}

  // show question on screen
	display() {
		question.innerText = this.displayQ;
    for (var i = 0; i < answers.length; i++) {
      answers[i].parentNode.lastChild.innerText = this.answers[i];
    }
	}

  // compare indicies of selected answer and correct answer
  testAnswer(selectedA) {
    return selectedA == this.correct;
  }
}

var answers = document.getElementsByName("answer");
var question = document.getElementById("question");

var questions = [];

var currentIndex = 0;

function setUp(){
	questions.push(new Question("Is this working?", ["Yes", "No", "Possibly", "AAAAAAAAAAAAAA"], 0));
  
	questions[0].display();
}

function submit() {
	console.log("hi")
	var index = -1;
	for(var i = 0; i < answers.length; i++){
		if(answers[i].checked){
			index = i;
		}
	}
  if(questions[currentIndex].testAnswer(index)){
		alert("yay");
	} else {
    alert("wrong, the correct answer was: " + String.fromCharCode(questions[currentIndex].correct + "A".charCodeAt(0)));
  }
	currentIndex++;
}

