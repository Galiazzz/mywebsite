//pixel class
class Pixel {
	constructor(r, g, b) {
		this.r = r;
		this.g = g;
		this.b = b;
	}
}

//variables
var img = [];
var width, height;

//helper functions
function drawPixel(x, y, pixel) {//yes, I know this function isn't actually drawing the pixel and that the putImageData function in the draw function is what actually draws it, but I wanted to avoid frivolous draw calls, so here we are.
	imageData[0].data[(x + y * width) * 4] = pixel.r;
	imageData[0].data[(x + y * width) * 4 + 1] = pixel.g;
	imageData[0].data[(x + y * width) * 4 + 2] = pixel.b;
}

//your code
function fiddleWithImage() {
	//add stuff here
	for(var y = 0; y < height; y++){
		for(var x = 0; x < width; x++){
			var multiplier = Math.hypot(x - width / 2, y - height / 2);
			var diagDist = Math.hypot(width / 2, height / 2);
			multiplier = 1 - multiplier / diagDist;
			drawPixel(x, y, new Pixel(img[y][x].r * multiplier,img[y][x].g * multiplier, img[y][x].b * multiplier));
		}
	}
}



// driving code
var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");

var temp = document.getElementById("temp");
var ctxTemp = temp.getContext("2d");

var image = document.getElementById("image");

var imageData = [];

requestAnimationFrame(Draw);

file.onchange = e => {
	const [f] = file.files;
	if (f) {
		image.src = URL.createObjectURL(f);
		loadImage();
	}
}

function ModifyImage() {
	for (var i = 0; i < imageData[0].data.length; i++) {
		imageData[0].data[i]++; //*= (i % 4 == 1) ? 2 : 5;
	}

}

function Draw() {


	if (typeof (imageData[0]) != "undefined") {
		if (typeof (imageData[0].data) != "undefined") {
			ctx.putImageData(imageData[0], 0, 0);
		}
	}
	requestAnimationFrame(Draw);
}


function loadImage() {

	image.onload = function() {
		image.style.display = "none";
		temp.style.display = "none";
		temp.height = image.height;
		temp.width = image.width;
		ctxTemp.drawImage(image, 0, 0);
		imageData[0] = (ctxTemp.getImageData(0, 0, image.width, image.height));
		canvas.height = image.height;
		canvas.width = image.width;

		width = image.width;
		height = image.height;
		for (var i = 0; i < image.height; i++) {
			img.push([]);
			for (var j = 0; j < image.width; j++) {
				img[i].push(new Pixel(imageData[0].data[(i * width + j) * 4], imageData[0].data[(i * width + j) * 4 + 1], imageData[0].data[(i * width + j) * 4 + 2]));
			}
		}
		fiddleWithImage();
	}
}