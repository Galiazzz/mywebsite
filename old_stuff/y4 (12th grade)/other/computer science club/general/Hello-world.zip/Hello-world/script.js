var canvas  = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

ctx.fillStyle = "white";

function LoadStuff(){

  ctx.fillRect(50, 50, 50, 50);
}