var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;


var x = 0;
var y = 50;

function LoadStuff(){
  ctx.fillStyle = "blue";
  ctx.fillRect(50, 50, 200, 200);

  requestAnimationFrame(Draw);

  setInterval(Update, 10);
}
function Hat() {
  ctx.fillstyle = "red";
  ctx.fillRect(55,55, 100, 100);

  setInterval(Update, 10);
  
}

var speed = 3;

function Update(){
  if(keysDown[0]){
    y += speed;
  }
  if (keysDown[1]) {
    x += speed;
  }
  if (keysDown[2]) {
    y -= speed;
  }
  if (keysDown[3]) {
    x -= speed;
  }
}

function Draw(){

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillRect(x, y, 25, 25);  
  requestAnimationFrame(Draw);
}

var keysDown = [];
for(var i = 0; i < 4; i++){
  keysDown.push(false);
}

document.addEventListener("keydown", function(e){
  if(e.key == "ArrowDown"){
    keysDown[0] = true;
  }
  if(e.key == "ArrowRight"){
    keysDown[1] = true;
  }
  if(e.key == "ArrowUp"){
    keysDown[2] = true;
  }
  if (e.key == "ArrowLeft") {
    keysDown[3] = true;
  }
})

document.addEventListener("keyup", function(e){
  if(e.key == "ArrowDown"){
    keysDown[0] = false;
  }
  if(e.key == "ArrowRight"){
    keysDown[1] = false;
  }
  if(e.key == "ArrowUp"){
    keysDown[2] = false;
  }
  if (e.key == "ArrowLeft") {
    keysDown[3] = false;
  }
})


