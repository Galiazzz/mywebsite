/*
  Author: Matthew Prem
  Date: 9-15-2022
  Purpose: create a rotating 3d cube that transforms into a red/cyan 3d anaglyph.
*/

var canvas = document.getElementById("canvas"); // get canvas
var ctx = canvas.getContext("2d"); //2d drawing context
canvas.width = window.innerWidth; //set to window size
canvas.height = window.innerHeight;

ctx.lineWidth = 3; //make the lines larger so that they overlap in the begninning

var theta = 0; //the current angle of the cube around the y-axis
var dt = 0; //the time passed since first update
var xPos = 0; //the offset of the two cameras

var cubeVerticies = [ //the positions of the 8 verticies of the cubes in x1, y1, z1, x2... format. This is before any rotations.
  1, 1, 1, 1, 1, -1, 1, -1, -1, 1, -1, 1,
  -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, -1, 1
];

var vertexPositions = [...cubeVerticies]; // a copy of the verticies to allow the rotation to take place.

var lineIndicies = [ //an array telling which points to connect with lines to form the wireframe.
  0, 1, 0, 3, 0, 4,
  1, 2, 1, 5,
  2, 3, 2, 6,
  3, 7,
  4, 5, 4, 7,
  5, 6,
  6, 7
];

function Rotate() {
  for (var i = 0; i < cubeVerticies.length / 3; i++) {
    //the rotaion for the x-coordinate
    vertexPositions[i * 3] = cubeVerticies[i * 3] * Math.cos(theta) - cubeVerticies[i * 3 + 2] * Math.sin(theta);
    //the rotation for the z-coordinate
    vertexPositions[i * 3 + 2] = cubeVerticies[i * 3] * Math.sin(theta) + cubeVerticies[i * 3 + 2] * Math.cos(theta);
  }
}

function LoadStuff() {
  setInterval(Update, 10); //set the update timer to be 100 ticks a second
  requestAnimationFrame(Draw); //start drawing to the screen
}

function Update() {
  theta += 0.004; //rotate the cube a little bit
  dt += 0.01; //tell how much time has passed (approximately)
  if (dt > 4 && dt < 6) { //move the two views apart between the fourth and sixth seconds
    xPos += 0.0005;
  }
  Rotate();
}

function Draw() {
  canvas.width = window.innerWidth; //resize the canvas in case of a window resize
  canvas.height = window.innerHeight;

  ctx.clearRect(0, 0, canvas.width, canvas.height); //clear the previous frame
  DrawCube(255, 0, 0, 1, xPos); //draw the right-eye (red) perspective
  DrawCube(0, 255, 255, 0.5, -xPos); //draw the left-eye (cyan) perspective
  requestAnimationFrame(Draw); //draw the next frame once this frame is done
  //left and right eyes are flipped from what you may expect, because it works best on a white background and subtractive color.
}

function DrawCube(r, g, b, a, camX) {
  var transformed = [];
  ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${a})`; //set the color to be drawn
  for (var i = 0; i < cubeVerticies.length / 3; i++) {
    //project the 3d space to 2d space making sure the cube is in front of the camera, and then transform the 2d square clip space coordinates to pixel space
    var coords = ClipToScreenSpace((vertexPositions[i * 3] - camX) / (vertexPositions[i * 3 + 2] + 3), vertexPositions[i * 3 + 1] / (vertexPositions[i * 3 + 2] + 3));
    //store the x and y projected values
    transformed.push(coords[0]);
    transformed.push(coords[1]);
  }
  ctx.beginPath(); //only draw lines from this render
  //connect the lines using the line indicies
  for (var i = 0; i < lineIndicies.length / 2; i++) {
    ctx.moveTo(transformed[lineIndicies[i * 2] * 2], transformed[lineIndicies[i * 2] * 2 + 1]);
    ctx.lineTo(transformed[lineIndicies[i * 2 + 1] * 2], transformed[lineIndicies[i * 2 + 1] * 2 + 1]);
  }
  ctx.stroke(); //draw the lines
}

//coordinate transform so that (0, 0) is in the center of the screen, (0, 1) is the top of the screen, (0, -1) is at the bottom of the screen, and make sure that one unit vertically is the same as one unit horizonally.
function ClipToScreenSpace(x, y) {
  return [(1 + x * (canvas.height / canvas.width)) * canvas.width / 2, (1 - y) * canvas.height / 2];
}