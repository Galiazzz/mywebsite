var canvas = document.getElementById("canvas");
canvas.height = window.innerHeight;
canvas.width = window.innerWidth;
var ctx = canvas.getContext("2d");

var nextTriangles = [{x: canvas.width/2, y:canvas.height/2, angle:0}];
var tempArray = [];

function loadStuff(){
	ctx.beginPath();
  var gradientCenter = {x: canvas.width / 2, y: canvas.height / 2 - 30};
  const gradient = ctx.createRadialGradient(gradientCenter.x, gradientCenter.y, 5, gradientCenter.x, gradientCenter.y, 40);
  gradient.addColorStop(0, "teal");
  gradient.addColorStop(0.3, "firebrick");
  gradient.addColorStop(0.75, "darkorange");
  gradient.addColorStop(1, "gold");
  
  ctx.fillStyle = gradient;
  drawSnowflake(10);
}

function drawSnowflake(depth){
	for (var i = 0; i < depth; i++) {
		for(var j = 0; j < nextTriangles.length; j++){
			var length = 81 * Math.pow(3, -i);
			var x = nextTriangles[j].x;
			var y = nextTriangles[j].y;
			console.log(nextTriangles[j]);
			tempArray.length = 0;
			drawTriangle(nextTriangles[j], nextTriangles[j].angle, length);
			tempArray.push({x: x + canvas.width / 2, y:y + canvas.height / 2, angle: nextTriangles[j].angle + Math.PI});
			tempArray.push({x: -0.25 * Math.sqrt(3) * length + x, y: 0.25 * length + y, angle: nextTriangles[j].angle + Math.PI / 3});
			tempArray.push({x: 0.25 * Math.sqrt(3) * length + x, y: 0.25 * length + y, angle: nextTriangles[j].angle - Math.PI / 3});
		}
    for(var j = 0; j < tempArray.length; j++){
			nextTriangles[j] = tempArray[j];
		}
  }
}

function drawTriangle(position, angle, size){
	ctx.beginPath();
	ctx.moveTo(position.x, position.y - Math.cos(angle) * size);
	ctx.lineTo(position.x + Math.cos(angle) * size * 0.5, position.y + Math.sin(angle) * size);
	ctx.lineTo(position.x - Math.cos(angle) * size * 0.5, position.y -Math.sin(angle) * size);
	ctx.fill();
  
}

//console.error(isTrue("hello"));
//console.error(isTrue(0));

function isTrue(bool) {
	return bool ? true : false;
}