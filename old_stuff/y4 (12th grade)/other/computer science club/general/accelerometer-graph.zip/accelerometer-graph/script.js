var canvases = [document.getElementById("cx"), document.getElementById("cy"), document.getElementById("cz")];
var ctxs = canvases.map(e => e.getContext("2d"));
canvases.forEach((e)=>{e.width = window.innerWidth - 50; e.height=window.innerHeight/3 - 50;});

for(var i =0; i < canvases.length; i++){
	ctxs[i].strokeStyle = "blue";
	ctxs[i].moveTo(0, canvases[i].height/2);
	ctxs[i].lineTo(canvases[i].width, canvases[i].height/2);
	ctxs[i].stroke();
}

var time = Date.now();
window.addEventListener("devicemotion", function(e){
	var newTime = Date.now();
		if(canvases[0].width < (newTime - time)/100){
			canvases.forEach(e=>e.width = (newTime-time)/100);
		}
		ctxs[0].fillRect((newTime - time) / 100, canvases[0].height / 2 - e.acceleration.x*5, 1, 1);
		ctxs[1].fillRect((newTime - time) / 100, canvases[0].height / 2 - e.acceleration.y*5, 1, 1);
		ctxs[2].fillRect((newTime - time) / 100, canvases[0].height / 2 - e.acceleration.z*5, 1, 1);
	})